package practiceprograms;


public class arrays {
	
	public static void main(String[] args) {
		int array[] = {2,2,31,3,45};
		for(int i=0;i<5;i++) {
		System.out.println(array[i]);
}
		int[][] arr = {{4, 656, 76, 98}, {23, 66, 79} };
	      
	    System.out.println("\nLength of row 2: " + arr[1].length);
	}
}